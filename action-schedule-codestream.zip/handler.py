import json
import requests




def handler(context, inputs):
    vraurl = inputs["vRealizeApplianceURL"]
    vrauser = inputs["codestreamUserName"]
    vrapass = inputs["codestreamPassword"]
    pipeline = inputs["pipelineUUID"]

    #Get Access Token for vRA
    requestUrl = vraurl+"/csp/gateway/am/api/login?access_token"
    headers = {"Content-Type": "application/json", "Accept": "application/json"}
    data = {"username":vrauser,"password":vrapass}
    response = requests.post(requestUrl, data=json.dumps(data), headers=headers, verify = False)
    print('Request response code is: ' + str(response.status_code))
    jsonResponse = response.json()
    authtoken = jsonResponse.get('access_token')
    print(authtoken)

    #Get Bearer Token for vRA
    requestUrl = vraurl+"/iaas/api/login"
    authtoken = jsonResponse.get('refresh_token')
    data = {"refreshToken":authtoken}
    response = requests.post(requestUrl, data=json.dumps(data), headers=headers, verify = False)
    print('Request response code is: ' + str(response.status_code))
    jsonResponse = response.json()
    bearertoken = jsonResponse.get('token')
    print(bearertoken)

    #Run Image Pipeline
    requestUrl = vraurl+"/codestream/api/pipelines/"+pipeline+"/executions"
    data = {}
    headers = {"Content-Type": "application/json", "Accept": "application/json", "Authorization":"Bearer "+bearertoken}
    response = requests.post(requestUrl, data=json.dumps(data), headers=headers, verify = False)
    print('Request response code is: ' + str(response.status_code))

    outputs = {
      "status": "done"
    }

    return outputs
